const exercises = {
    "Push-ups": "https://images.unsplash.com/photo-1599058917212-d750089bc07e?auto=format&fit=crop&w=1920&q=80",
    "Squats": "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=1920&q=80",
    "Plank": "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=1920&q=80",
    "Jumping Jacks": "https://images.unsplash.com/photo-1594737625785-a6cbdabd333c?auto=format&fit=crop&w=1920&q=80",
    "Lunges": "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=1920&q=80",
    "Mountain Climbers": "https://images.unsplash.com/photo-1598971639058-999b1e41a08a?auto=format&fit=crop&w=1920&q=80",
    "Burpees": "https://images.unsplash.com/photo-1579758629938-03607ccdbaba?auto=format&fit=crop&w=1920&q=80",
    "Sit-ups": "https://images.unsplash.com/photo-1605296867304-46d5465a13f1?auto=format&fit=crop&w=1920&q=80",
    "High Knees": "https://images.unsplash.com/photo-1549060279-7e168fcee0c2?auto=format&fit=crop&w=1920&q=80",
    "Shoulder Taps": "https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=1920&q=80",
    "Leg Raises": "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=1920&q=80",
    "Wall Sit": "https://images.unsplash.com/photo-1517964603305-11c0f6f66012?auto=format&fit=crop&w=1920&q=80",
    "Tricep Dips": "https://images.unsplash.com/photo-1599058918144-1ffabb6ab9a0?auto=format&fit=crop&w=1920&q=80",
    "Russian Twists": "https://images.unsplash.com/photo-1594381898411-846e7d193883?auto=format&fit=crop&w=1920&q=80",
    "Superman Hold": "https://images.unsplash.com/photo-1594736797933-d0c2c1b6c6fa?auto=format&fit=crop&w=1920&q=80",
    "Skipping": "https://images.unsplash.com/photo-1546484959-fb3fdf88d22a?auto=format&fit=crop&w=1920&q=80",
    "Side Plank": "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=1920&q=80",
    "Glute Bridge": "https://images.unsplash.com/photo-1594737625785-a6cbdabd333c?auto=format&fit=crop&w=1920&q=80",
    "Arm Circles": "https://images.unsplash.com/photo-1558611848-73f7eb4001a1?auto=format&fit=crop&w=1920&q=80",
    "Butt Kicks": "https://images.unsplash.com/photo-1549060279-7e168fcee0c2?auto=format&fit=crop&w=1920&q=80"
};

let select = document.getElementById("exerciseSelect");
let countDisplay = document.getElementById("count");
let progress = document.getElementById("progress");
let timeDisplay = document.getElementById("time");

let count = 0;
let limit = 0;
let timer = 0;
let timeLimit = 0;
let interval = null;
let active = false;

/* Load exercises */
for (let exercise in exercises) {
    let option = document.createElement("option");
    option.value = exercise;
    option.textContent = exercise;
    select.appendChild(option);
}

/* Change background */
select.addEventListener("change", function() {
    if (this.value) {
        document.body.style.backgroundImage = `url(${exercises[this.value]})`;
    }
});

/* Start */
function startExercise() {

    if (!select.value) {
        alert("Select Exercise First");
        return;
    }

    limit = parseInt(document.getElementById("limitInput").value);
    timeLimit = parseInt(document.getElementById("timeLimit").value);

    if (!limit || !timeLimit) {
        alert("Enter Reps and Time Limit");
        return;
    }

    count = 0;
    timer = 0;
    active = true;
    progress.style.width = "0%";
    countDisplay.textContent = 0;
    timeDisplay.textContent = 0;

    interval = setInterval(() => {
        timer++;
        timeDisplay.textContent = timer;

        if (timer >= timeLimit) {
            finishExercise();
        }

    }, 1000);

    speak("Exercise Started");
}

/* Stop */
function stopExercise() {
    active = false;
    clearInterval(interval);
    speak("Exercise Stopped");
}

/* Add Rep */
function addRep() {

    if (!active) return;

    count++;
    countDisplay.textContent = count;

    let percent = (count / limit) * 100;
    if (percent > 100) percent = 100;
    progress.style.width = percent + "%";

    if (count >= limit) {
        finishExercise();
    }
}

/* Finish */
function finishExercise() {
    active = false;
    clearInterval(interval);
    progress.style.width = "100%";
    speak("Exercise Over. Well Done LG-4!");
}

/* Voice */
function speak(text) {
    let speech = new SpeechSynthesisUtterance(text);
    speech.lang = "en-US";
    window.speechSynthesis.speak(speech);
}